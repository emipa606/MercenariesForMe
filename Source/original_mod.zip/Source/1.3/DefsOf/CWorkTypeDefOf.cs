﻿using Verse;
using RimWorld;

namespace aRandomKiwi.MFM
{
    [DefOf]
    public static class CWorkTypeDefOf
    {
        public static WorkTypeDef Firefighter;
        public static WorkTypeDef Patient;
        public static WorkTypeDef PatientBedRest;
    }
}