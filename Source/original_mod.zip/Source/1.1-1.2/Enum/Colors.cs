﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace aRandomKiwi.MFM
{
    public enum Colors
    {
        Black=1,
        White,
        Gray,
        Blue,
        Green,
        Red,
        Orange,
        Yellow,
        Purple,
        Pink,
        Cyan
    }
}
