﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace aRandomKiwi.MFM
{
    public enum MercenaryType
    {
        Melee=1,
        Ranged,
        Artist,
        Builder,
        Cooker,
        Farmer,
        Medical,
        Miner,
        Scientist,
        Speaker,
        Tech,
        Trainer
    }
}
