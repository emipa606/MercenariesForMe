﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace aRandomKiwi.MFM
{
    public enum MercenaryLevel
    {
        Recruit = 1,
        Confirmed = 2,
        Veteran = 3,
        Elite = 4,
        Cyborg = 5
    }
}
